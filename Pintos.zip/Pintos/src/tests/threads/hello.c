#include<stdio.h>

void printmsg()
{
	printf("Hello, World!");
}
